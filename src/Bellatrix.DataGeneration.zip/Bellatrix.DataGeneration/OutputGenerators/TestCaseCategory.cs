﻿namespace Bellatrix.DataGeneration.OutputGenerators;
public enum TestCaseCategory
{
    All,
    Valid,
    Validation
}
