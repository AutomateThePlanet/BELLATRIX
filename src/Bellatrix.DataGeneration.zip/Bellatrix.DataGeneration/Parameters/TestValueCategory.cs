﻿namespace Bellatrix.DataGeneration.Parameters;
public enum TestValueCategory
{
    BoundaryValid,
    BoundaryInvalid,
    Valid,
    Invalid
}